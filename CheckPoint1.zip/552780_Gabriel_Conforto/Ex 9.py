numeros_pares = []
numeros_impares = []
for numero in range(101):
    if numero % 2 == 0:
        numeros_pares.append(numero)
    else:
        numeros_impares.append(numero)

print("Números Pares:", numeros_pares)
print("Números Ímpares:", numeros_impares)