letra = str(input('Digite uma letra'))

vogal = ['a','e', 'i', 'o', 'u']
letra.lower()
while len(letra) > 1:
    print('Digite APENAS uma letra ')
    letra = str(input('Digite uma letra'))


if  letra in vogal:
    print('A letra é uma vogal')
else:
    print('A letra é uma consoante')
