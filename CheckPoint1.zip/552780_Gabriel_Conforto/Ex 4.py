numeros = [1, 5, 6, 8]

print(numeros)

media = sum(numeros)/len(numeros)

print(media)
