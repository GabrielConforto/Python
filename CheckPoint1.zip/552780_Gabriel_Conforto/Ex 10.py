saldo = 1950
while saldo >= 10:
    saque = int(input('Valor que deseja sacar'))
    while saque < 10 or saque>saldo:
        print('Insira um valor de saque válido')
        saque = int(input('Valor que deseja sacar'))
       
    if saque >=10 and saque<=saldo:
        n200 = int(saque/200)
        r1 = saque % 200
        n100 = int(r1/100)
        r2 = r1 % 100
        n50 = int(r2/50)
        r3 = r2 % 50
        n10 = int(r3/10)
        r4 = r3 % 10
        n5 = int(r4/5)
        r5 = r4 % 5
        n1 = r5
        print(f'Você recebe {n200} notas de 200, {n100} notas de 100, {n50} notas de 50, {n10} notas de 10, {n5} notas de 5 e {n1} notas de 1')
print('O saldo da máquina é baixo demais para esse saque')