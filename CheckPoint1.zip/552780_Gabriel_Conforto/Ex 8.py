aluno = str(input('Digite o nome do aluno'))
nota1 = float(input('Forneça a primeira nota'))
nota2 = float(input('Forneça a segunda nota'))
nota3 = float(input('Forneça a terceira nota'))
media = (nota1 + nota2 + nota3)/3

if media < 7:
    print(f'O aluno {aluno} não foi aprovado')

else:
        print(f'O aluno {aluno} foi aprovado')
