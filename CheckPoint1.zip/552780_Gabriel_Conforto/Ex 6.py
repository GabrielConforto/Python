numero = int(input('Forneça um número'))

invert = numero * (-1)

print(f'O número invertido é {invert}')
