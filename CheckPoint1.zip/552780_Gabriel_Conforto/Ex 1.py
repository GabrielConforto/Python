numeros = list(range(10, 1595))
soma = sum(numeros)
print(numeros)
print(f'A soma é {soma}')