palavra = input('Palavra')

arvalap = palavra[::-1]

if palavra == arvalap:
    print('É um palíndromo')
	
else:
    print('Não é um palíndormo')
