num =  int(input('Forneça um número'))

if num % 5 == 0:
    print('Seu número é múltiplo de 5')
else:
    print('Seu número não é múltiplo de 5')
