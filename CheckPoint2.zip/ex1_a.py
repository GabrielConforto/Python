resultado = ''
cod = 'next na arca 2023'
chave = list(cod)
for i in range(0,len(cod)):
    resultado = resultado + chr(ord(chave[i])+1)
    print(resultado)

