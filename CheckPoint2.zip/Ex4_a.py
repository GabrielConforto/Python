dolar = 5

def US():
    conv = 1946*5
    print(conv, 'dólares')

US()
