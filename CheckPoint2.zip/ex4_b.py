euro = 5.30

def EU():
    conv = round(5379 * euro,2)
    print(conv,'euros')


EU()
