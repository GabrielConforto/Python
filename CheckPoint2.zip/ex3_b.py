texto = 'A tecnologia revolucionou nossas vidas. A internet nos conecta  globalmente, mas a privacidade é ameaçada pela coleta de dados. As redes  sociais mantêm laços familiares e de amizade. Porém, notícias falsas  obscurecem a verdade. Precisamos usar a tecnologia com responsabilidade, equilibrando-a com o mundo offline para nosso bem-estar'
list(texto)

n = 'n'
count = 0

for n in texto:
    count = count+ 1
print(f'{count} letras "n"')
