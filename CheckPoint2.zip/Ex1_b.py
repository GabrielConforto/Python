resultado = ''
cod = 'fbehuvhfxulwb fs2 2023'
chave = list(cod)
for i in range(0,len(chave)):
    resultado = resultado + chr(ord(chave[i])-3)
    print(resultado)
