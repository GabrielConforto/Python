import random
texto = "24680#+@#*&!%"
result=(random.sample(texto,12))
print(result)
