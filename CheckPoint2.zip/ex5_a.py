def fahr():
    fahrenheit = -459.4
    celsius = (fahrenheit - 32) * 1.8
    print(celsius,'°C')
fahr()
