import random
texto = "13579#+@#*&!%"
result=(random.sample(texto,12))
print(result)
