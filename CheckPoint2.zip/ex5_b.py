def cel():
    celsius = -459.4
    fahrenheit = celsius*1.8+32
    print(celsius,'°F')
cel()
